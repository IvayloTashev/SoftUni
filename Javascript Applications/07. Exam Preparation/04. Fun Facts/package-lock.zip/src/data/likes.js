import { get, put, post, del } from "./request.js"

const endpoints = {
    like: "/data/likes",
    
}